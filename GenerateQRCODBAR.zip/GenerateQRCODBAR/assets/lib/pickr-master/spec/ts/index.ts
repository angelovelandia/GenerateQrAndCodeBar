import Pickr from '../../types/pickr';

const options: Pickr.Options = {
    el: '.my-el'
};

const instance: Pickr = new Pickr(options);
