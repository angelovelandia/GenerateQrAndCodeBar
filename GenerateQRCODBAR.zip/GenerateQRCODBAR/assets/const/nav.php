<ul class="navbar-nav ml-auto">
  <li class="nav-item dropdown dropleft">
    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown_one" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Pepito Perez
    </a>
      <div class="dropdown-menu la" aria-labelledby="navbarDropdown_one">
        <a onclick="_Admin.traerVista('index');" class="dropdown-item" href="#"><i class="fas fa-home"></i> Inicio</a>
      </div>
  </li>
</ul>
 