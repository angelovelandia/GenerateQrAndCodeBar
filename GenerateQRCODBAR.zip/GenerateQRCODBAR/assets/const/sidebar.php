<!-- Inicio de barra lateral   -->
<div class="d-flex ">
    <div id="sidebar-container" class="bg-primary">
        <div class="logo">
            <h5 id="sidebarmostrar" class="text-light decore-underline font-weight-bold">Angelus Tech</h5>
        </div>
        <div class="menu">
          <ul class="acorh">
            <li onclick="_Admin.traerVista('index');"><a href="#" class="d-block p-3 text-light"><i class="fas fa-border-none"></i> Dashboard</a></li>
            <li onclick="_Admin.traerVista('codQR');"><a href="#"><i class="fas fa-qrcode"></i> Codigo QR</a></li>
            <li onclick="_Admin.traerVista('codBar');"><a href="#"><i class="fas fa-barcode"></i> Codigo de barras</a></li>
          </ul>
        </div>
    </div>
<!-- Fin de barra lateral   -->