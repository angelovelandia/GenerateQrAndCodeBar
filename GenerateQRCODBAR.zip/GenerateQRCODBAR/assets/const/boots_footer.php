<!-- Modern or es5 bundle -->
<script src="assets/lib/pickr-master/dist/pickr.min.js"></script>
<script src="assets/lib/pickr-master/dist/pickr.es5.min.js"></script>
<!-- JS Interno -->
<script src="assets/js/admin.js"></script>
<script src="assets/js/index.js"></script>
<!-- JS Bootstrap -->
<script src="assets/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/lib/bootstrap/js/bootstrap.min.js" ></script>

